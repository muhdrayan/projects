import sqlite3, time 

number = (((2**3)+2)*300)+(5**2)+1
chances = 0

while True:
    guess = input("Type in your hacker password: ")
    if int(guess) == number:
        print("Password correct.")
        break 
    else:
        chances += 1
        if chances >= 3:
            print("Too many incorrect tries. Session terminated.")
            exit()
        print(f"Wrong. You have {3-chances} chances left.")
        


time.sleep(1)

db = sqlite3.connect("bank.db")
c = db.cursor()

mobile_no = input("Who do you want to hack (mobile number): ")

c.execute("SELECT *,oid FROM users")
information = c.fetchall()

for info in information:
    if str(info[0]) == mobile_no:

        person = input(f"Is {info[2]} the person whom you want to hack? (y/n): ")
        if person == "y":
            choice = input("Person successfully hacked. Do you want to see previous passwords? (y/n): ")
            if choice == "y":
                print("Password 1:", info[1],"Password 2:",info[3])
            else:
                print("Okay...")

            choice = input("Do you want to reset your password? (y/n): ")
            if choice == "y":
                passwords = input("Enter password1 and password2: ")
                passwords = passwords.split(" ")

                c.execute("UPDATE users SET pincode=:p, pincode_2=:p2 WHERE oid=:oid",{"p":passwords[0],"p2":passwords[1],"oid":info[5]})
                db.commit()

            else: print("okay... hacking session stopped.")
        else:
            print("Run this program again.")
            exit()





